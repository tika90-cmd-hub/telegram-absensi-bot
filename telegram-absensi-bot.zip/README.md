# Telegram Absensi Bot
Bot untuk mencatat aktivitas harian di Telegram.